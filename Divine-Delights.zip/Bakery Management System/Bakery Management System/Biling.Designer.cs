﻿namespace WindowsFormsApplication1
{
    partial class Biling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Biling));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BProductDGV = new System.Windows.Forms.DataGridView();
            this.prodIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodQtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodCatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bakerydbDataSet4 = new WindowsFormsApplication1.BakerydbDataSet4();
            this.BillingDGV = new System.Windows.Forms.DataGridView();
            this.Sid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salesTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bakerydbDataSet9 = new WindowsFormsApplication1.BakerydbDataSet9();
            this.customerTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bakerydbDataSet5 = new WindowsFormsApplication1.BakerydbDataSet5();
            this.AddBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.BQtyTb = new System.Windows.Forms.TextBox();
            this.BPriceTb = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.CustomerCb = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.YourBillDGV = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GrdTotallb1 = new System.Windows.Forms.Label();
            this.SaveBillBtn = new System.Windows.Forms.Button();
            this.productTblTableAdapter = new WindowsFormsApplication1.BakerydbDataSet4TableAdapters.ProductTblTableAdapter();
            this.customerTblTableAdapter = new WindowsFormsApplication1.BakerydbDataSet5TableAdapters.CustomerTblTableAdapter();
            this.salesTblTableAdapter = new WindowsFormsApplication1.BakerydbDataSet9TableAdapters.SalesTblTableAdapter();
            this.sidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BProdNameTb = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.BProductDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bakerydbDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BillingDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bakerydbDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bakerydbDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YourBillDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(382, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "Divine Delights";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(422, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Biling Module";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(61, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 27);
            this.label3.TabIndex = 2;
            this.label3.Text = "Customer";
            // 
            // BProductDGV
            // 
            this.BProductDGV.AutoGenerateColumns = false;
            this.BProductDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.BProductDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prodIdDataGridViewTextBoxColumn,
            this.prodNameDataGridViewTextBoxColumn,
            this.prodQtyDataGridViewTextBoxColumn,
            this.prodPriceDataGridViewTextBoxColumn,
            this.prodCatDataGridViewTextBoxColumn});
            this.BProductDGV.DataSource = this.productTblBindingSource;
            this.BProductDGV.Location = new System.Drawing.Point(849, 25);
            this.BProductDGV.Name = "BProductDGV";
            this.BProductDGV.RowTemplate.Height = 24;
            this.BProductDGV.Size = new System.Drawing.Size(508, 329);
            this.BProductDGV.TabIndex = 3;
            this.BProductDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.BProductDGV_CellContentClick);
            // 
            // prodIdDataGridViewTextBoxColumn
            // 
            this.prodIdDataGridViewTextBoxColumn.DataPropertyName = "ProdId";
            this.prodIdDataGridViewTextBoxColumn.HeaderText = "ProdId";
            this.prodIdDataGridViewTextBoxColumn.Name = "prodIdDataGridViewTextBoxColumn";
            this.prodIdDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // prodNameDataGridViewTextBoxColumn
            // 
            this.prodNameDataGridViewTextBoxColumn.DataPropertyName = "ProdName";
            this.prodNameDataGridViewTextBoxColumn.HeaderText = "ProdName";
            this.prodNameDataGridViewTextBoxColumn.Name = "prodNameDataGridViewTextBoxColumn";
            // 
            // prodQtyDataGridViewTextBoxColumn
            // 
            this.prodQtyDataGridViewTextBoxColumn.DataPropertyName = "ProdQty";
            this.prodQtyDataGridViewTextBoxColumn.HeaderText = "ProdQty";
            this.prodQtyDataGridViewTextBoxColumn.Name = "prodQtyDataGridViewTextBoxColumn";
            // 
            // prodPriceDataGridViewTextBoxColumn
            // 
            this.prodPriceDataGridViewTextBoxColumn.DataPropertyName = "ProdPrice";
            this.prodPriceDataGridViewTextBoxColumn.HeaderText = "ProdPrice";
            this.prodPriceDataGridViewTextBoxColumn.Name = "prodPriceDataGridViewTextBoxColumn";
            // 
            // prodCatDataGridViewTextBoxColumn
            // 
            this.prodCatDataGridViewTextBoxColumn.DataPropertyName = "ProdCat";
            this.prodCatDataGridViewTextBoxColumn.HeaderText = "ProdCat";
            this.prodCatDataGridViewTextBoxColumn.Name = "prodCatDataGridViewTextBoxColumn";
            // 
            // productTblBindingSource
            // 
            this.productTblBindingSource.DataMember = "ProductTbl";
            this.productTblBindingSource.DataSource = this.bakerydbDataSet4;
            // 
            // bakerydbDataSet4
            // 
            this.bakerydbDataSet4.DataSetName = "BakerydbDataSet4";
            this.bakerydbDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // BillingDGV
            // 
            this.BillingDGV.AutoGenerateColumns = false;
            this.BillingDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BillingDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.BillingDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Sid,
            this.CustomerId,
            this.SAmount,
            this.SDate,
            this.sidDataGridViewTextBoxColumn,
            this.customerIdDataGridViewTextBoxColumn,
            this.sAmountDataGridViewTextBoxColumn,
            this.sDateDataGridViewTextBoxColumn});
            this.BillingDGV.DataSource = this.salesTblBindingSource;
            this.BillingDGV.Location = new System.Drawing.Point(849, 426);
            this.BillingDGV.Name = "BillingDGV";
            this.BillingDGV.RowTemplate.Height = 24;
            this.BillingDGV.Size = new System.Drawing.Size(465, 329);
            this.BillingDGV.TabIndex = 4;
            // 
            // Sid
            // 
            this.Sid.DataPropertyName = "Sid";
            this.Sid.HeaderText = "Sid";
            this.Sid.Name = "Sid";
            this.Sid.ReadOnly = true;
            // 
            // CustomerId
            // 
            this.CustomerId.DataPropertyName = "CustomerId";
            this.CustomerId.HeaderText = "CustomerId";
            this.CustomerId.Name = "CustomerId";
            // 
            // SAmount
            // 
            this.SAmount.DataPropertyName = "SAmount";
            this.SAmount.HeaderText = "SAmount";
            this.SAmount.Name = "SAmount";
            // 
            // SDate
            // 
            this.SDate.DataPropertyName = "SDate";
            this.SDate.HeaderText = "SDate";
            this.SDate.Name = "SDate";
            // 
            // salesTblBindingSource
            // 
            this.salesTblBindingSource.DataMember = "SalesTbl";
            this.salesTblBindingSource.DataSource = this.bakerydbDataSet9;
            // 
            // bakerydbDataSet9
            // 
            this.bakerydbDataSet9.DataSetName = "BakerydbDataSet9";
            this.bakerydbDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerTblBindingSource
            // 
            this.customerTblBindingSource.DataMember = "CustomerTbl";
            this.customerTblBindingSource.DataSource = this.bakerydbDataSet5;
            // 
            // bakerydbDataSet5
            // 
            this.bakerydbDataSet5.DataSetName = "BakerydbDataSet5";
            this.bakerydbDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // AddBtn
            // 
            this.AddBtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddBtn.Location = new System.Drawing.Point(437, 351);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(140, 45);
            this.AddBtn.TabIndex = 5;
            this.AddBtn.Text = "Add To Bill";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(62, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 27);
            this.label4.TabIndex = 6;
            this.label4.Text = "Product Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(452, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 27);
            this.label5.TabIndex = 7;
            this.label5.Text = "Quantity";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(452, 274);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 27);
            this.label6.TabIndex = 8;
            this.label6.Text = "Price";
            // 
            // BQtyTb
            // 
            this.BQtyTb.Location = new System.Drawing.Point(611, 161);
            this.BQtyTb.Name = "BQtyTb";
            this.BQtyTb.Size = new System.Drawing.Size(100, 22);
            this.BQtyTb.TabIndex = 11;
            // 
            // BPriceTb
            // 
            this.BPriceTb.Location = new System.Drawing.Point(611, 272);
            this.BPriceTb.Name = "BPriceTb";
            this.BPriceTb.Size = new System.Drawing.Size(100, 22);
            this.BPriceTb.TabIndex = 12;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(181, 352);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(140, 45);
            this.button2.TabIndex = 13;
            this.button2.Text = "Refresh";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(247, 422);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 27);
            this.label7.TabIndex = 14;
            this.label7.Text = "Client Bill";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // CustomerCb
            // 
            this.CustomerCb.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerCb.FormattingEnabled = true;
            this.CustomerCb.Location = new System.Drawing.Point(257, 167);
            this.CustomerCb.Name = "CustomerCb";
            this.CustomerCb.Size = new System.Drawing.Size(100, 23);
            this.CustomerCb.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1054, 396);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 27);
            this.label8.TabIndex = 16;
            this.label8.Text = "Biling List";
            // 
            // YourBillDGV
            // 
            this.YourBillDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.YourBillDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.YourBillDGV.Location = new System.Drawing.Point(23, 452);
            this.YourBillDGV.Name = "YourBillDGV";
            this.YourBillDGV.RowTemplate.Height = 24;
            this.YourBillDGV.Size = new System.Drawing.Size(544, 277);
            this.YourBillDGV.TabIndex = 17;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "ID";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Product";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Quantity";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Price";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Total";
            this.Column5.Name = "Column5";
            // 
            // GrdTotallb1
            // 
            this.GrdTotallb1.AutoSize = true;
            this.GrdTotallb1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrdTotallb1.Location = new System.Drawing.Point(304, 732);
            this.GrdTotallb1.Name = "GrdTotallb1";
            this.GrdTotallb1.Size = new System.Drawing.Size(53, 23);
            this.GrdTotallb1.TabIndex = 18;
            this.GrdTotallb1.Text = "Total";
            // 
            // SaveBillBtn
            // 
            this.SaveBillBtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveBillBtn.Location = new System.Drawing.Point(646, 533);
            this.SaveBillBtn.Name = "SaveBillBtn";
            this.SaveBillBtn.Size = new System.Drawing.Size(128, 45);
            this.SaveBillBtn.TabIndex = 19;
            this.SaveBillBtn.Text = "Save Bill";
            this.SaveBillBtn.UseVisualStyleBackColor = true;
            this.SaveBillBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // productTblTableAdapter
            // 
            this.productTblTableAdapter.ClearBeforeFill = true;
            // 
            // customerTblTableAdapter
            // 
            this.customerTblTableAdapter.ClearBeforeFill = true;
            // 
            // salesTblTableAdapter
            // 
            this.salesTblTableAdapter.ClearBeforeFill = true;
            // 
            // sidDataGridViewTextBoxColumn
            // 
            this.sidDataGridViewTextBoxColumn.DataPropertyName = "Sid";
            this.sidDataGridViewTextBoxColumn.HeaderText = "Sid";
            this.sidDataGridViewTextBoxColumn.Name = "sidDataGridViewTextBoxColumn";
            this.sidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // customerIdDataGridViewTextBoxColumn
            // 
            this.customerIdDataGridViewTextBoxColumn.DataPropertyName = "CustomerId";
            this.customerIdDataGridViewTextBoxColumn.HeaderText = "CustomerId";
            this.customerIdDataGridViewTextBoxColumn.Name = "customerIdDataGridViewTextBoxColumn";
            // 
            // sAmountDataGridViewTextBoxColumn
            // 
            this.sAmountDataGridViewTextBoxColumn.DataPropertyName = "SAmount";
            this.sAmountDataGridViewTextBoxColumn.HeaderText = "SAmount";
            this.sAmountDataGridViewTextBoxColumn.Name = "sAmountDataGridViewTextBoxColumn";
            // 
            // sDateDataGridViewTextBoxColumn
            // 
            this.sDateDataGridViewTextBoxColumn.DataPropertyName = "SDate";
            this.sDateDataGridViewTextBoxColumn.HeaderText = "SDate";
            this.sDateDataGridViewTextBoxColumn.Name = "sDateDataGridViewTextBoxColumn";
            // 
            // BProdNameTb
            // 
            this.BProdNameTb.FormattingEnabled = true;
            this.BProdNameTb.Location = new System.Drawing.Point(257, 277);
            this.BProdNameTb.Name = "BProdNameTb";
            this.BProdNameTb.Size = new System.Drawing.Size(100, 24);
            this.BProdNameTb.TabIndex = 20;
            this.BProdNameTb.SelectedIndexChanged += new System.EventHandler(this.BProdNameTb_SelectedIndexChanged);
            // 
            // Biling
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.BProdNameTb);
            this.Controls.Add(this.SaveBillBtn);
            this.Controls.Add(this.GrdTotallb1);
            this.Controls.Add(this.YourBillDGV);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CustomerCb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.BPriceTb);
            this.Controls.Add(this.BQtyTb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.AddBtn);
            this.Controls.Add(this.BillingDGV);
            this.Controls.Add(this.BProductDGV);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.Name = "Biling";
            this.Text = "Form6";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Biling_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BProductDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bakerydbDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BillingDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bakerydbDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bakerydbDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YourBillDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView BProductDGV;
        private System.Windows.Forms.DataGridView BillingDGV;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox BQtyTb;
        private System.Windows.Forms.TextBox BPriceTb;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox CustomerCb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView YourBillDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.Label GrdTotallb1;
        private System.Windows.Forms.Button SaveBillBtn;
        private BakerydbDataSet4 bakerydbDataSet4;
        private System.Windows.Forms.BindingSource productTblBindingSource;
        private BakerydbDataSet4TableAdapters.ProductTblTableAdapter productTblTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodQtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodCatDataGridViewTextBoxColumn;
        private BakerydbDataSet5 bakerydbDataSet5;
        private System.Windows.Forms.BindingSource customerTblBindingSource;
        private BakerydbDataSet5TableAdapters.CustomerTblTableAdapter customerTblTableAdapter;
        private BakerydbDataSet9 bakerydbDataSet9;
        private System.Windows.Forms.BindingSource salesTblBindingSource;
        private BakerydbDataSet9TableAdapters.SalesTblTableAdapter salesTblTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sid;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerId;
        private System.Windows.Forms.DataGridViewTextBoxColumn SAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn sidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox BProdNameTb;
    }
}