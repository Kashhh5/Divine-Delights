﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Customer : Form
    {
        private SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=""D:\projects of c#\Bakery Management System\Bakery Management System\Bakerydb.mdf"";Integrated Security=True;Connect Timeout=30");
       

        private int Ckey = 0;

        public Customer()
        {
            InitializeComponent();
        }

        private void AddCustBtn_Click(object sender, EventArgs e)
        {
            if (CNameTb.Text == "" || CAddressTb.Text == "" || CPhoneTb.Text == "")
            {
                MessageBox.Show("Missing Information!!!");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO CustomerTbl(CustName, CustPhone, CustAddress) VALUES (@CN, @CP, @CA)", Con);
                    cmd.Parameters.AddWithValue("@CN", CNameTb.Text);
                    cmd.Parameters.AddWithValue("@CP", CPhoneTb.Text);
                    cmd.Parameters.AddWithValue("@CA", CAddressTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Added!!!");

                    // Refresh DataGridView
                    DisplayDataInDataGridView();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        private void CustomerDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = CustomerDGV.Rows[e.RowIndex];
                CNameTb.Text = row.Cells["CustName"].Value.ToString();
                CPhoneTb.Text = row.Cells["CustPhone"].Value.ToString();
                CAddressTb.Text = row.Cells["CustAddress"].Value.ToString();

                if (CNameTb.Text == "")
                {
                    Ckey = 0;
                }
                else
                {
                    Ckey = Convert.ToInt32(row.Cells["CustId"].Value.ToString());
                }
            }
        }

        private void DelCustBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(CNameTb.Text))
            {
                MessageBox.Show("Missing Information!!!");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM CustomerTbl WHERE CustName=@CKey", Con);
                    cmd.Parameters.AddWithValue("@CKey", CNameTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" Deleted!!!");

                  
                    DisplayDataInDataGridView();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Database error: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        private void EditCustBtn_Click(object sender, EventArgs e)
        {
            if (CNameTb.Text == "" || CAddressTb.Text == "" || CPhoneTb.Text == "")
            {
                MessageBox.Show("Missing Information!!!");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE CustomerTbl SET CustName=@CN, CustPhone=@CP, CustAddress=@CA WHERE CustId=@CKey", Con);
                    cmd.Parameters.AddWithValue("@CN", CNameTb.Text);
                    cmd.Parameters.AddWithValue("@CP", CPhoneTb.Text);
                    cmd.Parameters.AddWithValue("@CA", CAddressTb.Text);
                    cmd.Parameters.AddWithValue("@CKey", Ckey);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Updated!!!");

                    // Refresh DataGridView
                    DisplayDataInDataGridView();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        private void Customer_Load(object sender, EventArgs e)
        {
            
            this.customerTblTableAdapter.Fill(this.bakerydbDataSet3.CustomerTbl);

            
            DisplayDataInDataGridView();

          
        }

        private void DisplayDataInDataGridView()
        {
            try
            {
                string query = "SELECT * FROM CustomerTbl";
                SqlDataAdapter abc = new SqlDataAdapter(query, Con);
                DataTable dt = new DataTable();
                abc.Fill(dt);

                // Bind data to DataGridView
                CustomerDGV.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error: " + ex.Message);
            }
            finally
            {
                Con.Close();
            }
        }
    }
}
