﻿namespace WindowsFormsApplication1
{
    partial class Category
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Category));
            this.CategoryDGV = new System.Windows.Forms.DataGridView();
            this.categoryTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bakerydbDataSet6 = new WindowsFormsApplication1.BakerydbDataSet6();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.CatNameTb = new System.Windows.Forms.TextBox();
            this.EditCatBtn = new System.Windows.Forms.Button();
            this.AddCatBtn = new System.Windows.Forms.Button();
            this.DeleteCatBtn = new System.Windows.Forms.Button();
            this.categoryTblTableAdapter = new WindowsFormsApplication1.BakerydbDataSet6TableAdapters.CategoryTblTableAdapter();
            this.CatId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CatName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.CategoryDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bakerydbDataSet6)).BeginInit();
            this.SuspendLayout();
            // 
            // CategoryDGV
            // 
            this.CategoryDGV.AutoGenerateColumns = false;
            this.CategoryDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CategoryDGV.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CategoryDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.CategoryDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CatId,
            this.CatName});
            this.CategoryDGV.DataSource = this.categoryTblBindingSource;
            this.CategoryDGV.Location = new System.Drawing.Point(410, 347);
            this.CategoryDGV.Name = "CategoryDGV";
            this.CategoryDGV.RowTemplate.Height = 24;
            this.CategoryDGV.Size = new System.Drawing.Size(728, 271);
            this.CategoryDGV.TabIndex = 0;
            // 
            // categoryTblBindingSource
            // 
            this.categoryTblBindingSource.DataMember = "CategoryTbl";
            this.categoryTblBindingSource.DataSource = this.bakerydbDataSet6;
            // 
            // bakerydbDataSet6
            // 
            this.bakerydbDataSet6.DataSetName = "BakerydbDataSet6";
            this.bakerydbDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(699, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 38);
            this.label1.TabIndex = 1;
            this.label1.Text = "Divine Delights";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(724, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "Manage Categories";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(523, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 27);
            this.label3.TabIndex = 3;
            this.label3.Text = "Category Name";
            // 
            // CatNameTb
            // 
            this.CatNameTb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatNameTb.Location = new System.Drawing.Point(767, 143);
            this.CatNameTb.Name = "CatNameTb";
            this.CatNameTb.Size = new System.Drawing.Size(335, 30);
            this.CatNameTb.TabIndex = 4;
            // 
            // EditCatBtn
            // 
            this.EditCatBtn.Location = new System.Drawing.Point(0, 0);
            this.EditCatBtn.Name = "EditCatBtn";
            this.EditCatBtn.Size = new System.Drawing.Size(75, 23);
            this.EditCatBtn.TabIndex = 8;
            // 
            // AddCatBtn
            // 
            this.AddCatBtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddCatBtn.Location = new System.Drawing.Point(491, 226);
            this.AddCatBtn.Name = "AddCatBtn";
            this.AddCatBtn.Size = new System.Drawing.Size(145, 56);
            this.AddCatBtn.TabIndex = 6;
            this.AddCatBtn.Text = "ADD";
            this.AddCatBtn.UseVisualStyleBackColor = true;
            this.AddCatBtn.Click += new System.EventHandler(this.AddCatBtn_Click);
            // 
            // DeleteCatBtn
            // 
            this.DeleteCatBtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteCatBtn.Location = new System.Drawing.Point(941, 227);
            this.DeleteCatBtn.Name = "DeleteCatBtn";
            this.DeleteCatBtn.Size = new System.Drawing.Size(145, 55);
            this.DeleteCatBtn.TabIndex = 7;
            this.DeleteCatBtn.Text = "DELETE";
            this.DeleteCatBtn.UseVisualStyleBackColor = true;
            this.DeleteCatBtn.Click += new System.EventHandler(this.DeleteCatBtn_Click);
            // 
            // categoryTblTableAdapter
            // 
            this.categoryTblTableAdapter.ClearBeforeFill = true;
            // 
            // CatId
            // 
            this.CatId.DataPropertyName = "CatId";
            this.CatId.HeaderText = "CatId";
            this.CatId.Name = "CatId";
            this.CatId.ReadOnly = true;
            // 
            // CatName
            // 
            this.CatName.DataPropertyName = "CatName";
            this.CatName.HeaderText = "CatName";
            this.CatName.Name = "CatName";
            // 
            // Category
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.DeleteCatBtn);
            this.Controls.Add(this.AddCatBtn);
            this.Controls.Add(this.EditCatBtn);
            this.Controls.Add(this.CatNameTb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CategoryDGV);
            this.DoubleBuffered = true;
            this.Name = "Category";
            this.Text = "Form5";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Category_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CategoryDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bakerydbDataSet6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView CategoryDGV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox CatNameTb;
        private System.Windows.Forms.Button EditCatBtn;
        private System.Windows.Forms.Button AddCatBtn;
        private System.Windows.Forms.Button DeleteCatBtn;
        private BakerydbDataSet6 bakerydbDataSet6;
        private System.Windows.Forms.BindingSource categoryTblBindingSource;
        private BakerydbDataSet6TableAdapters.CategoryTblTableAdapter categoryTblTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn CatId;
        private System.Windows.Forms.DataGridViewTextBoxColumn CatName;
    }
}