﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Category : Form
    {
        private SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=""D:\projects of c#\Bakery Management System\Bakery Management System\Bakerydb.mdf"";Integrated Security=True;Connect Timeout=30");
        private int Catkey = 0;

        public Category()
        {
            InitializeComponent();
        }

        private void CategoryDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = CategoryDGV.Rows[e.RowIndex];
                CatNameTb.Text = row.Cells["CatName"].Value.ToString();

                if (CatNameTb.Text == "")
                {
                    Catkey = 0;
                }
                else
                {
                    Catkey = Convert.ToInt32(row.Cells["CatID"].Value.ToString());
                }
            }
        }

        private void DisplayDataInDataGridView()
        {
            try
            {
                
                string query = "SELECT * FROM CategoryTbl";
                SqlDataAdapter abc = new SqlDataAdapter(query, Con);
                DataTable dt = new DataTable();
                abc.Fill(dt);

                // Bind data to DataGridView
                CategoryDGV.DataSource = dt;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Database error: " + ex.Message);
            }
            finally
            {
                
                if (Con.State == ConnectionState.Open)
                {
                    Con.Close();
                }
            }
        }


        private void AddCatBtn_Click(object sender, EventArgs e)
        {
            if (CatNameTb.Text == "")
            {
                MessageBox.Show("Missing Information!!!");
            }
            else
            {
                try
                {
                    Con.Open();
                    string insertQuery = "INSERT INTO CategoryTbl(CatName)VALUES (@CN)";
                    SqlCommand cmd = new SqlCommand(insertQuery, Con);
                    cmd.Parameters.AddWithValue("@CN",CatNameTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Category Added!!!");
                   

                    // Refresh DataGridView
                    DisplayDataInDataGridView();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        private void DeleteCatBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(CatNameTb.Text))
            {
                MessageBox.Show("Missing Information!!!");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM CategoryTbl WHERE CatName=@CKey", Con);
                    cmd.Parameters.AddWithValue("@CKey", CatNameTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Catagory Deleted!!!");

                    // Refresh DataGridView
                    DisplayDataInDataGridView();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Database error: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }


        private void Category_Load(object sender, EventArgs e)
        {
            
            this.categoryTblTableAdapter.Fill(this.bakerydbDataSet6.CategoryTbl);

            
            DisplayDataInDataGridView();
        }
    }
}
