﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Biling : Form
    {
        int quan;
        public Biling()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=""D:\projects of c#\Bakery Management System\Bakery Management System\Bakerydb.mdf"";Integrated Security=True;Connect Timeout=30");


        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {


        }
        int BPkey = 0;
        int stock = 0;
        private void BProductDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            BProdNameTb.Text = BProductDGV.SelectedRows[0].Cells[1].Value.ToString();
          
            BPriceTb.Text = BProductDGV.SelectedRows[0].Cells[3].Value.ToString();
            
            if (BProdNameTb.Text != "")
            {
                BPkey = Convert.ToInt32(BProductDGV.SelectedRows[0].Cells[0].Value.ToString());
                stock = Convert.ToInt32(BProductDGV.SelectedRows[0].Cells[2].Value.ToString());   
            }
            else
            {
                BPkey = 0;
                stock = 0;
            }
        }
        int n = 0;
        int GrdTotal = 0;
        private void AddBtn_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(BQtyTb.Text) <= quan)
            {
                
                int total = Convert.ToInt32(BQtyTb.Text) * Convert.ToInt32(BPriceTb.Text);
                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(YourBillDGV);
                newRow.Cells[0].Value = n + 1;
                newRow.Cells[1].Value = BProdNameTb.Text;
                newRow.Cells[2].Value = BQtyTb.Text;
                newRow.Cells[3].Value = BPriceTb.Text;
                newRow.Cells[4].Value = total;
                YourBillDGV.Rows.Add(newRow);
                n++;
            }
            else
            {
                MessageBox.Show("Not Enough stock!!!");
            }
            
        }
        private void GetCustomer()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select CustId from CustomerTbl", Con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CustId", typeof(int));
            dt.Load(Rdr);
            CustomerCb.ValueMember = "CustId";
            CustomerCb.DataSource = dt;
            Con.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            CustomerCb.Text = "";
            BPriceTb.Text = "";
            BQtyTb.Text = "";
            BProdNameTb.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String BPriceTb1 = BPriceTb.Text;
            int Price = Convert.ToInt32(BPriceTb1);
            String BQtyTb1 = BQtyTb.Text;
            int Qty = int.Parse(BQtyTb1);
            int GrdTotal = Price * Qty;
            if (CustomerCb.Text == "")
            {
                MessageBox.Show("Missing Information!!!");
            }
            else
            {
                try
                {
                    Con.Open();
                    string insertQuery = "Insert into SalesTbl(CustomerId,SAmount,SDate)values(@CA,@SA,@SD)";
                    SqlCommand cmd = new SqlCommand(insertQuery, Con);
           
                    cmd.Parameters.AddWithValue("@CA", CustomerCb.Text.ToString());
                    cmd.Parameters.AddWithValue("@SA", GrdTotal);
                    cmd.Parameters.AddWithValue("@SD", DateTime.Today.Date);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Sales Added!!!");
                   
                    // DisplayElements("SalesTbl", BillingListDGV);
                    BPriceTb.Text = "";
                    BQtyTb.Text = "";
                    BProdNameTb.Text = "";
                    CustomerCb.Text = "";
                }

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        private void Biling_Load(object sender, EventArgs e)
        {
            
            this.salesTblTableAdapter.Fill(this.bakerydbDataSet9.SalesTbl);
            
            this.customerTblTableAdapter.Fill(this.bakerydbDataSet5.CustomerTbl);
            
            this.productTblTableAdapter.Fill(this.bakerydbDataSet4.ProductTbl);

            populate();
        }

         private void populate()
        {
            Con.Open();
            string que = "Select ProdName from ProductTbl";
             using (SqlCommand insertcmd = new SqlCommand(que, Con))
            {
                using (SqlDataReader reader = insertcmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string ProdName = reader.GetString(0);
                        BProdNameTb.Items.Add(ProdName);
                    }
                    Con.Close();
                }
            }
             Con.Open();
             string que1 = "Select CustId from CustomerTbl";
             using (SqlCommand insertcmd = new SqlCommand(que1, Con))
             {
                 using (SqlDataReader reader = insertcmd.ExecuteReader())
                 {
                     while (reader.Read())
                     {
                         int custname = reader.GetInt32(0);
                         CustomerCb.Items.Add(custname);
                     }
                     Con.Close();
                 }
             }
        }

         private void BProdNameTb_SelectedIndexChanged(object sender, EventArgs e)
         {
             string pname = BProdNameTb.SelectedItem.ToString();
             if (pname !="")
             {
                 Con.Open();
                 string que2 = "Select ProdPrice , ProdQty from ProductTbl where ProdName = @pro ";
                 using (SqlCommand insertcmd1 = new SqlCommand(que2, Con))
                 {
                     insertcmd1.Parameters.AddWithValue("@pro", pname);
                     using (SqlDataReader reader1 = insertcmd1.ExecuteReader())
                     {
                         while (reader1.Read())
                         {
                             int pricepro = reader1.GetInt32(0);
                             quan = reader1.GetInt32(0);
                             
                             BPriceTb.Text = pricepro.ToString();
                         }
                         Con.Close();
                     }
                 }
             }
             
         }

    }
}
