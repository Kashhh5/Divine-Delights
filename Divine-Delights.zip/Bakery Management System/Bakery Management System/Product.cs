﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Product : Form
    {
        private SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\projects of c#\Bakery Management System\Bakery Management System\Bakerydb.mdf;Integrated Security=True;Connect Timeout=30");

        public Product()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            
          
            this.productTblTableAdapter1.Fill(this.bakerydbDataSet1.ProductTbl);
            DisplayDataInDataGridView();
        }
        private void ProductDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = ProductDGV.Rows[e.RowIndex];
                ProductNameTb.Text = row.Cells["ProdName"].Value.ToString();
                QuantityTb.Text = row.Cells["ProdQty"].Value.ToString();
                PriceTb.Text = row.Cells["ProdPrice"].Value.ToString();
                CatCb.SelectedItem = row.Cells["ProdCat"].Value.ToString(); 
            }
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ProductNameTb.Text) || string.IsNullOrEmpty(QuantityTb.Text) || string.IsNullOrEmpty(PriceTb.Text) || CatCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information!!!");
            }
            else
            {
                try
                {
                    Con.Open();

                    string insertQuery = "INSERT INTO ProductTbl(ProdName, ProdCat, ProdPrice, ProdQty) VALUES (@PN, @PC, @PP, @PQ)";
                    SqlCommand insertcmd = new SqlCommand(insertQuery, Con);
                    insertcmd.Parameters.AddWithValue("@PN", ProductNameTb.Text);
                    insertcmd.Parameters.AddWithValue("@PC", CatCb.SelectedItem.ToString());
                    insertcmd.Parameters.AddWithValue("@PP", PriceTb.Text);
                    insertcmd.Parameters.AddWithValue("@PQ", QuantityTb.Text);
                    insertcmd.ExecuteNonQuery();
                    MessageBox.Show("Product Added!!!");

                    
                    DisplayDataInDataGridView();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Database error: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

       
        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ProductNameTb.Text) || string.IsNullOrEmpty(QuantityTb.Text) || string.IsNullOrEmpty(PriceTb.Text) || CatCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information!!!");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE ProductTbl SET ProdName=@PN, ProdCat=@PC, ProdPrice=@PP, ProdQty=@PQ WHERE ProdName=@PKey", Con);
                    cmd.Parameters.AddWithValue("@PN", ProductNameTb.Text);
                    cmd.Parameters.AddWithValue("@PC", CatCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@PP", PriceTb.Text);
                    cmd.Parameters.AddWithValue("@PQ", QuantityTb.Text);
                    cmd.Parameters.AddWithValue("@PKey", ProductNameTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Product Updated!!!");

                    
                    DisplayDataInDataGridView();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Database error: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ProductNameTb.Text))
            {
                MessageBox.Show("Missing Information!!!");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM ProductTbl WHERE ProdName=@PKey", Con);
                    cmd.Parameters.AddWithValue("@PKey", ProductNameTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Product Deleted!!!");

                    // Refresh DataGridView
                    DisplayDataInDataGridView();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Database error: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        private void DisplayDataInDataGridView()
        {
            try
            {
                
                string query = "SELECT * FROM ProductTbl";
                SqlDataAdapter abc = new SqlDataAdapter(query, Con);
                DataTable dt = new DataTable();
                abc.Fill(dt);

                // Bind data to DataGridView
                ProductDGV.DataSource = dt;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Database error: " + ex.Message);
            }
            finally
            {
                Con.Close();
            }
        }

        private void CatCb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
